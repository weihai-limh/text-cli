#!/bin/bash
echo "Stopping text-cli services..."

lsof -ti tcp:20260 | xargs kill 2>/dev/null || true
lsof -ti tcp:28050 | xargs kill 2>/dev/null || true
lsof -ti tcp:9020  | xargs kill 2>/dev/null || true

echo "Done - copilot :20260, service :28050, mcp :9020 stopped."
