@echo off
chcp 65001 >nul
title text-cli v0.1.0

echo ========================================
echo   text-cli v0.1.0 - Windows
echo ========================================
echo.

:: env
if "%TEXT_CLI_HOME%"=="" set "TEXT_CLI_HOME=%~dp0"
echo [OK] TEXT_CLI_HOME = %TEXT_CLI_HOME%

:: python check
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERR] Python not installed or not in PATH
    pause
    exit /b 1
)

:: pip deps (one-time)
if not exist "%TEXT_CLI_HOME%.deps_ok" (
    echo [INFO] installing Python deps...
    pip install -r "%TEXT_CLI_HOME%service\requirements.txt" --quiet
    if %errorlevel% neq 0 (
        echo [ERR] pip install failed
        pause
        exit /b 1
    )
    echo. > "%TEXT_CLI_HOME%.deps_ok"
    echo [OK] deps ready
)

:: config init
if not exist "%TEXT_CLI_HOME%copilot\auxiliary_config.json" (
    if exist "%TEXT_CLI_HOME%copilot\auxiliary_config.example.json" (
        copy "%TEXT_CLI_HOME%copilot\auxiliary_config.example.json" "%TEXT_CLI_HOME%copilot\auxiliary_config.json" >nul
        echo [OK] copilot config initialized
    )
)

:: start copilot (127.0.0.1:20260)
echo.
echo [INFO] starting copilot (http://127.0.0.1:20260)...
start "text-cli-copilot" /MIN python "%TEXT_CLI_HOME%copilot\text-cli-copilot.py"
ping -n 4 127.0.0.1 >nul
echo [OK] copilot started

:: start service (0.0.0.0:28050)
echo [INFO] starting service (http://0.0.0.0:28050)...
start "text-cli-service" /MIN python "%TEXT_CLI_HOME%service\main.py"
ping -n 6 127.0.0.1 >nul

:: health check
echo.
echo [INFO] health check...
curl -s http://localhost:28050/text-cli/health 2>nul
if %errorlevel% equ 0 (
    echo.
    echo [OK] text-cli v0.1.0 deployed!
    echo.
    echo   copilot : http://127.0.0.1:20260
    echo   service : http://0.0.0.0:28050
    echo.
    echo   test: curl -X POST http://localhost:28050/text-cli/cli -H "Content-Type: application/json" -d "{\"directive\": \"AI:基础应用;天气查询,北京\"}"
    echo.
) else (
    echo [WARN] health check failed - check logs
)
echo   docs: docs\README_zh.md
echo ========================================
pause
