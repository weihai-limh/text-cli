@echo off
echo Stopping text-cli endpoint...

for /f "tokens=5" %%a in ('netstat -ano ^| findstr :29050 ^| findstr LISTENING') do (
    taskkill /PID %%a /F >nul 2>&1
    if not errorlevel 1 echo   endpoint PID %%a stopped
)

echo Done - endpoint :29050 stopped.
pause
