@echo off
chcp 65001 >nul
title text-cli-endpoint v0.1.1

echo ========================================
echo   text-cli endpoint v0.1.1 - Windows
echo ========================================
echo.

:: env
if "%A3_BACKENDS%"=="" (
    echo [WARN] A3_BACKENDS not set — endpoint will have no backend services
    echo        Set this to your Service URL (e.g. http://localhost:28050),
    echo        or create backends.yaml for multi-backend setups ^(recommended^).
    echo        See docs/README_zh.md for configuration details.
) else (
    echo [OK] A3_BACKENDS = %A3_BACKENDS%
)
if "%ACCESS_TOKEN_REQUIRED%"=="" set "ACCESS_TOKEN_REQUIRED=true"
echo [INFO] ACCESS_TOKEN_REQUIRED = %ACCESS_TOKEN_REQUIRED%
if "%ENDPOINT_BASE_URL%"=="" set "ENDPOINT_BASE_URL=http://localhost:29050"
echo [OK] ENDPOINT_BASE_URL = %ENDPOINT_BASE_URL%
if "%TEXT_CLI_ENDPOINT_HOME%"=="" set "TEXT_CLI_ENDPOINT_HOME=%~dp0"
echo [OK] HOME = %TEXT_CLI_ENDPOINT_HOME%

:: python check
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERR] Python not installed or not in PATH
    pause
    exit /b 1
)

:: venv deps (isolated from global pip)
set "VENV_PYTHON=%TEXT_CLI_ENDPOINT_HOME%.venv\Scripts\python.exe"
if exist "%VENV_PYTHON%" (
    "%VENV_PYTHON%" -c "import fastapi,uvicorn,httpx,pydantic" >nul 2>&1
    if not errorlevel 1 (
        echo [OK] deps ready (venv)
        goto :deps_done
    )
)
echo [INFO] installing Python deps to .venv...
if not exist "%TEXT_CLI_ENDPOINT_HOME%.venv" (
    python -m venv "%TEXT_CLI_ENDPOINT_HOME%.venv"
)
"%VENV_PYTHON%" -m pip install -r "%TEXT_CLI_ENDPOINT_HOME%requirements.txt" --quiet
if %errorlevel% neq 0 (
    echo [ERR] pip install failed
    pause
    exit /b 1
)
echo [OK] deps ready
:deps_done

:: start endpoint (0.0.0.0:29050)
echo.
echo [INFO] starting endpoint (http://0.0.0.0:29050)...
cd /d "%TEXT_CLI_ENDPOINT_HOME%"
"%VENV_PYTHON%" -m uvicorn main:app --host 0.0.0.0 --port 29050
