"""Copilot instruction packages."""
