"""Copilot instruction packages."""
