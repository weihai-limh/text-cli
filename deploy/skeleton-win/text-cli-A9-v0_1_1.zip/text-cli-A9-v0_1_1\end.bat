@echo off
echo Stopping text-cli services...

for /f "tokens=5" %%a in ('netstat -ano ^| findstr :20260 ^| findstr LISTENING') do (
    taskkill /PID %%a /F >nul 2>&1
    if not errorlevel 1 echo   copilot PID %%a stopped
)

for /f "tokens=5" %%a in ('netstat -ano ^| findstr :28050 ^| findstr LISTENING') do (
    taskkill /PID %%a /F >nul 2>&1
    if not errorlevel 1 echo   service PID %%a stopped
)

for /f "tokens=5" %%a in ('netstat -ano ^| findstr :9020 ^| findstr LISTENING') do (
    taskkill /PID %%a /F >nul 2>&1
    if not errorlevel 1 echo   mcp PID %%a stopped
)

echo Done - copilot :20260, service :28050, mcp :9020 stopped.
pause
