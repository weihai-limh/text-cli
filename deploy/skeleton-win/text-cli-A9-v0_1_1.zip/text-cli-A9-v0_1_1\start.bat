@echo off
chcp 65001 >nul
title text-cli-A3+ v0.1.1

echo ========================================
echo   text-cli A3+ v0.1.1 - Windows
echo ========================================
echo.

:: env
if "%TEXT_CLI_HOME%"=="" set "TEXT_CLI_HOME=%~dp0"
echo [OK] TEXT_CLI_HOME = %TEXT_CLI_HOME%

:: Package source directory (default: sibling packages/ next to extracted archive)
if "%TEXT_CLI_PACKAGE_SOURCE_DIRS%"=="" (
    set "TEXT_CLI_PACKAGE_SOURCE_DIRS=%~dp0..\packages"
)
if not exist "%TEXT_CLI_PACKAGE_SOURCE_DIRS%" (
    echo [WARN] Package source directory not found: %TEXT_CLI_PACKAGE_SOURCE_DIRS%
    echo        To install packages, place them in this directory or set
    echo        TEXT_CLI_PACKAGE_SOURCE_DIRS to your package source location.
) else (
    echo [OK] TEXT_CLI_PACKAGE_SOURCE_DIRS = %TEXT_CLI_PACKAGE_SOURCE_DIRS%
)

:: python check
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERR] Python not installed or not in PATH
    pause
    exit /b 1
)

:: config (text_cli.yaml)
set "CONFIG_YAML=%TEXT_CLI_HOME%service\\config\\text_cli.yaml"
if exist "%CONFIG_YAML%" (
    echo [config] text_cli.yaml found at: service\\config\\text_cli.yaml
) else (
    if exist "%TEXT_CLI_HOME%service\\config\\text_cli.example.yaml" (
        echo [config] text_cli.example.yaml found; rename to text_cli.yaml or start will auto-init
    )
)
echo [config] env vars override YAML settings (see docs/user-manual_zh.md 1.5)
:: venv deps (isolated from global pip)
set "VENV_PYTHON=%TEXT_CLI_HOME%.venv\Scripts\python.exe"
if exist "%VENV_PYTHON%" (
    "%VENV_PYTHON%" -c "import fastapi,uvicorn,pydantic,httpx" >nul 2>&1
    if not errorlevel 1 (
        echo [OK] deps ready (venv)
        goto :deps_done
    )
)
echo [INFO] installing Python deps to .venv...
if not exist "%TEXT_CLI_HOME%.venv" (
    python -m venv "%TEXT_CLI_HOME%.venv"
)
"%VENV_PYTHON%" -m pip install -r "%TEXT_CLI_HOME%service\requirements.txt" --quiet
if %errorlevel% neq 0 (
    echo [ERR] pip install failed
    pause
    exit /b 1
)
echo [OK] deps ready
:deps_done

:: config init
if not exist "%TEXT_CLI_HOME%copilot\auxiliary_config.json" (
    if exist "%TEXT_CLI_HOME%copilot\auxiliary_config.example.json" (
        copy "%TEXT_CLI_HOME%copilot\auxiliary_config.example.json" "%TEXT_CLI_HOME%copilot\auxiliary_config.json" >nul
        echo [OK] copilot config initialized
    )
)
if not exist "%TEXT_CLI_HOME%service\config\text_cli.yaml" (
    if exist "%TEXT_CLI_HOME%service\config\text_cli.example.yaml" (
        copy "%TEXT_CLI_HOME%service\config\text_cli.example.yaml" "%TEXT_CLI_HOME%service\config\text_cli.yaml" >nul
        echo [OK] text_cli.yaml initialized
    )
)
:: start copilot (127.0.0.1:20260)
echo.
echo [INFO] starting copilot (http://127.0.0.1:20260)...
start "text-cli-copilot" /MIN "%VENV_PYTHON%" "%TEXT_CLI_HOME%copilot\text-cli-copilot.py"
ping -n 4 127.0.0.1 >nul
echo [OK] copilot started
:: start service (0.0.0.0:28050)
echo [INFO] starting service (http://0.0.0.0:28050)...
start "text-cli-service" /MIN "%VENV_PYTHON%" "%TEXT_CLI_HOME%service\main.py"
ping -n 6 127.0.0.1 >nul
:: health check
echo.
echo [INFO] health check...
curl -s http://localhost:28050/text-cli/health 2>nul
if %errorlevel% equ 0 (
    echo.
    echo [OK] text-cli A3+ v0.1.1 deployed!
    echo.
    echo   copilot : http://127.0.0.1:20260
    echo   service : http://0.0.0.0:28050
    echo.
    echo   test: curl -X POST http://localhost:28050/text-cli/cli -H "Content-Type: application/json" -d "{\"prompt\": \"AI:text-cli;query,compact\"}"
    echo.
) else (
    echo [WARN] health check failed - check logs
)
echo   docs: docs\README_zh.md
echo ========================================
pause
