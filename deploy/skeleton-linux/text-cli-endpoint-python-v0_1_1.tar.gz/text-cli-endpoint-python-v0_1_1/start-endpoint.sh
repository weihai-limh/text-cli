#!/bin/bash
set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
export TEXT_CLI_ENDPOINT_HOME="${TEXT_CLI_ENDPOINT_HOME:-$DIR}"

echo "========================================"
echo "  text-cli endpoint v0.1.1 - Linux"
echo "========================================"
echo ""
echo "[OK] HOME = $TEXT_CLI_ENDPOINT_HOME"

# python check
if ! command -v python3 &>/dev/null; then
    echo "[ERR] python3 not installed or not in PATH"
    exit 1
fi

# pip deps (one-time)
if [ ! -f "$TEXT_CLI_ENDPOINT_HOME/.deps_ok" ]; then
    echo "[INFO] installing Python deps..."
    pip3 install -r "$TEXT_CLI_ENDPOINT_HOME/requirements.txt" --quiet
    if [ $? -ne 0 ]; then
        echo "[ERR] pip install failed"
        exit 1
    fi
    touch "$TEXT_CLI_ENDPOINT_HOME/.deps_ok"
    echo "[OK] deps ready"
fi

# start endpoint (0.0.0.0:29050)
echo ""
echo "[INFO] starting endpoint (http://0.0.0.0:29050)..."
cd "$TEXT_CLI_ENDPOINT_HOME"
python3 -m uvicorn main:app --host 0.0.0.0 --port 29050
